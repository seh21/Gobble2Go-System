import os
from MyTutorial.settings import BASE_DIR
# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '9yrqfbo$-cxey5y8by6^5u*fy6+1yt9b&sdl@b!mb5sh&d29xd'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = []

# Database
# https://docs.djangoproject.com/en/1.10/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, '..', 'database', 'db.sqlite3'),
    }
}

