from django.conf.urls import url
from django.contrib import admin
from main.views import home, form, invalid
from main.views import thanks1, thanks2, thanks3, thanks4, thanks5, thanks6, thanks7, thanks8
 
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^form/', form),
    url(r'^thanks1/', thanks1),
    url(r'^thanks2/', thanks2),
    url(r'^thanks3/', thanks3),
    url(r'^thanks4/', thanks4),
    url(r'^thanks5/', thanks5),
    url(r'^thanks6/', thanks6),
    url(r'^thanks7/', thanks7),
    url(r'^thanks8/', thanks8),
    url(r'^invalid/', invalid),
    url(r'^$', home),
]
