from django import forms

class SurveyForm(forms.Form):
    name = forms.CharField(label="Name:", initial="John Smith")
    email = forms.CharField(label="Email:", initial="PID@vt.edu")
    idnum = forms.CharField(label="Student ID:", initial="905812345")
    rest = forms.ChoiceField(
        label="Restaurant:",
        choices=(('Qdoba','Qdoba'),('JambaJuice','JambaJuice'),('FireGrill','FireGrill'),('AtomicPizza','AtomicPizza'),('BrueggersBagels','BrueggersBagels'),('DolceCaffe','DolceCaffe'),('Origami','Origami')),)
    time = forms.CharField(label="Pick-up Time:", initial="12:30")
    agreement = forms.BooleanField(label="Terms and Conditions", required=True)

