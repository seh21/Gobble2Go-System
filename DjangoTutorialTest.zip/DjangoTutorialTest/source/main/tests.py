from django.core.urlresolvers import resolve
from django.test import TestCase
from django.http import HttpRequest
from main.models import Article
from main.views import home, form
from main.forms import SurveyForm
 
# Create your tests here.
class HomepageTest(TestCase):
 
    def test_root_resolves_to_home(self):
        root=resolve('/')
        self.assertEqual(root.func,home)
 
    def test_root_loads_index_html(self):
        request = HttpRequest()
        response = home(request)
        self.assertTrue(response.content.startswith(b'<!DOCTYPE HTML>\n<html>\n<head>'))
        self.assertIn("Hello World",response.content.decode())
 
 
class ModelTest(TestCase):
 
    def setUp(self):
        self.test_title = "TEST My Awesome Article TEST"
        self.test_body = "This is a text"
        Article.objects.create(
            title=self.test_title,
            body=self.test_body)
        self.article = Article.objects.all().filter(
            title=self.test_title)
 
    def tearDown(self):
        self.article.delete()
 
    def test_able_to_save_entries_to_db(self):
        self.assertEqual(self.article.values()[0]['body'],self.test_body)
 
    def test_index_html_displays_article(self):
        request = HttpRequest()
        response = home(request)
        self.assertTrue(
            response.content.startswith(
                b'<!DOCTYPE HTML>\n<html>\n<head>'))
        self.assertIn(self.test_body,response.content.decode())

class FormTest(TestCase):
 
    def setUp(self):
        self.request = HttpRequest()
        self.post_dict = {'name':'Zach Taylor','email':'example@gmail.com', 'idnum':'123456789', 'rest':'QD', 'time':'9:00', 'agreement':True}
 
    def test_form_renders_on_page_properly(self):
        response = form(self.request)
        for i in ['form','name','email','idnum','rest','time','agreement']:
            self.assertIn(i,response.content.decode())
 
    def test_form_redirection(self):
 
        def agreement_n_test(agreement,red_url):
            self.post_dict['agreement'] = agreement
            response = self.client.post('/form/',self.post_dict)
            self.assertRedirects(response,red_url)
 
        agreement_n_test(False,'/invalid/')
        agreement_n_test(True, '/thanks/')
