# Written by Zachary Taylor
# December 14th, 2016
# Viewing Form System for Gobble 2 Go

from django.shortcuts import render
from main.models import Article
from main.forms import SurveyForm
from django.http import HttpResponseRedirect
import socket
import json

# Definition of Socket with Server
maker = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
maker.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
maker.connect(('172.30.63.244',2000))
size = 1024

# Create your views here.
def home(request):
	article = Article.objects.last()
	return render(request,'index.html',{'article':article},)

# Create Form Document
def form(request):
	def redirection(locker):
		if int(locker) == 7:
			return HttpResponseRedirect('/thanks8/')
		elif int(locker) == 6:
			return HttpResponseRedirect('/thanks7/')
		elif int(locker) == 5:
			return HttpResponseRedirect('/thanks6/')
		elif int(locker) == 4:
			return HttpResponseRedirect('/thanks5/')
		elif int(locker) == 3:
			return HttpResponseRedirect('/thanks4/')
		elif int(locker) == 2:
			return HttpResponseRedirect('/thanks3/')
		elif int(locker) == 1:
			return HttpResponseRedirect('/thanks2/')
		elif int(locker) == 0:
			return HttpResponseRedirect('/thanks1/')
		elif int(locker) == -1:
			return HttpResponseRedirect('/invalid/')

	# Fill Out Form
	form = SurveyForm()
	
	if request.method == 'POST':
		form = SurveyForm(request.POST)
		# Get Data From Form
		studname = form.data['name']
		print(studname)
		studemail = form.data['email']
		print(studemail)
		studidnum = form.data['idnum']
		print(studidnum)
		studrest = form.data['rest']
		print(studrest)
		studtime = form.data['time']
		print(studtime)
		studOrd = {'name':studname, 'email':studemail, 'idnum':studidnum, 'rest':studrest, 'time':studtime}
		studOrdJson = json.dumps(studOrd)
		if form.is_valid():
			maker.send(studOrdJson.encode())
			print('Sending: %s' % studOrdJson)
			data = maker.recv(size)
			print('Redirecting for locker: %s' % data)
			return redirection(data.decode())
	else:
		form = SurveyForm()

	return render(request,'form.html',{'form': form},)
 
def invalid(request):
	return render(request,'invalid.html')
 
def thanks1(request):
	return render(request,'thanks1.html')
def thanks2(request):
	return render(request,'thanks2.html')
def thanks3(request):
	return render(request,'thanks3.html')
def thanks4(request):
	return render(request,'thanks4.html')
def thanks5(request):
	return render(request,'thanks5.html')
def thanks6(request):
	return render(request,'thanks6.html')
def thanks7(request):
	return render(request,'thanks7.html')
def thanks8(request):
	return render(request,'thanks8.html')

